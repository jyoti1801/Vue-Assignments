<template>
<div>
    <h3>Products List</h3>
    <br/>
    <label>Sort By Price</label>
    <select v-model="sorted">
        <option value="asc">Low to High</option>
        <option value="desc"> High to Low</option>
        
    </select>
    <button @click="arrange">Sort By Price</button>
    <br/>
    <table>
        <tr>
            <th>Id</th>
            <th> Product Name</th>
            <th>Price</th>
        </tr>
        <tr v-for="p in products" :key="p.id">
            <td>{{p.id}}</td>
            <td>{{p.name}}</td>
            <td>{{p.price}}</td>

        </tr>
    </table>
</div>

    
</template>

<script>
export default {
    name:"ProductSort",
    data(){
        return{
            products:[
                {id:1,name:"Television",price:20000},
                {id:2,name:"Laptop",price:30000},
                {id:3,name:"Mobile",price:10000},
                {id:4,name:"Soap",price:40},
                {id:5,name:"Powder",price:90}
            ],
            sorted:""
        };
    },
    methods:{
        arrange(){
            if(this.sorted=="asc")
            this.products.sort(function(a,b){
                return a.price-b.price;
            });
            else
              this.products.sort(function(a,b){
                return b.price-a.price;

        });
    }
    }
    
}
</script>

<style scoped>

</style>