<template>
<div>
    <h3> States and City Lists</h3>
    <br/>
    <h5>State Dropdown</h5>
    <select v-model="selectedState" required>
        <option v-for="(s,i) in state " :key="i" :value="s">{{s}}</option>
    </select>
    <br/>
    <br/>
    <div v-if="selectedState=='AndhraPradesh'"><h5>City Dropdown</h5>
    <select v-model="selectedCity" required>
        <option v-for="(a,j) in ApCities" :key="j" :value="a">{{a}}</option>
    </select>
     <br/>
     <br/>

    </div>
    <div v-if="selectedState=='Maharashtra'"><h5>City Dropdown</h5>
    <select v-model="selectedCity" required>
        <option v-for="(m,k) in MhCities" :key="k" :value="m">{{m}}</option>
    </select>
     <br/>
     <br/>

    </div>
    <div v-if="selectedState=='Telangana'"><h5>City Dropdown</h5>
    <select v-model="selectedCity" required>
        <option v-for="(t,l) in TlCities" :key="l" :value="t">{{t}}</option>
    </select>
     <br/>
     <br/>

    </div>
    <div v-if="selectedState=='Karnataka'"><h5>City Dropdown</h5>
    <select v-model="selectedCity" required>
        <option v-for="(r,n) in KaCities" :key="n" :value="r">{{r}}</option>
    </select>
     <br/>
     <br/>

    </div>
</div>
</template>
<script>
export default {
    name:"CityList",
    data(){
        return{
            state:["AndhraPradesh","Maharashtra","Karnataka","Telangana"],
            ApCities:["Vishakhapatnam","Vijayawada","Amravati","Tirupati","Guntur"],
            MhCities:["Mumbai","Pune","Nagpur","Nashik","Aurangabad"],
            TlCities:["Hyderabad","Warangal","Karimnagar","Nizamabad","Nalgonda"],
            KaCities:["Bengaluru","Mangalore","Mysuru","Belgaum","Hubli"],
            selectedState:"",
            selectedCity:""
        }
    }
    
}
</script>
<style scoped>
</style>