<template>
    <div>
        <h3>Product Details</h3>
        <br/>
        
        <h5>Category:</h5>

        <select v-model="selectedCategory" required> 
            <option v-for="(c,i) in category" :key="i" :value="c">{{c}}</option>
        </select >
        <br/>
        <br/>
        <div v-if="selectedCategory=='Electronics'"><h5>Product:</h5>
            <select v-model="selectedProduct" required>
                <option v-for="(e,k) in electronicsList" :key="k" :value="e">{{e.name}}</option>
            </select>
            <br/>
        <br/>

        </div>
        <div v-if="selectedCategory=='Grocery'"><h5>Product:</h5>
            <select v-model="selectedProduct" required>
                <option v-for="(g,j) in groceryList" :key="j" :value="g">{{g.name}}</option>
            </select>

        </div>
        <div>
            <h5>Quantity:</h5>
            <input type="text" v-model= "quantity" required />
        </div>
        <div>
            <h5>Price:</h5>
            <input type="text" v-model="totalPrice" disabled/>
            
        </div>
        <br/>
        <button @click="calculatePrice" type="button">Submit</button>&nbsp;&nbsp;
        <button @click="clear" type="button">Clear</button>

    </div>
</template>
<script>
export default {
    name:"Products",
    data(){
        return{
            category:["Electronics","Grocery"],
            electronicsList:[
                {name:"Television", price:20000},
                {name:"Laptop", price:30000},
                {name:"Mobile",  price:10000}
                
            ],
            groceryList:[
                {name:"Soap", price:40},
                {name:"Powder", price:90}
                
            ],
            selectedCategory:"",
            selectedProduct:{},
            quantity:"",
            totalPrice:"",
            product:""
        }
    },
    methods:{
        calculatePrice(){
            this.totalPrice=""+(this.selectedProduct.price)* parseInt(this.quantity);
        },
        clear(){
            this.selectedCategory=""
            this.selectedProduct=""
            this.quantity=""
            this.totalPrice=""
        }

    }
    
}
</script>
<style scoped>
</style>