import Vue from "vue";
import App from "./App.vue";

Vue.config.productionTip = false;

// to avoid Vue to output a 'you are in development mode'

new Vue({
  render: h => h(App)
}).$mount("#app");
