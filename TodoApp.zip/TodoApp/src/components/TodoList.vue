<template>
  <div>
    <input  id="todo" type="text" v-model="task" />
    <button @click="addTask">Add Task</button>
    <ul>
      <li><input type="checkbox" id="selectAll" @change="selectAll()" v-model="select"><label for="selectAll">Select All</label></li>
      <li v-for="(todo, i) in todos" :key="i">
        <input type="checkbox" :id="todo" :value="todo" v-model="checked" />
       
        <label :for="todo">
        {{todo}}
        </label>
        
      </li>
    </ul>
    <button @click="removeSelectedTask">Remove</button>
  </div>
</template>

<script>
export default {
  name: "TodoList",
  data() {
    return {
      todos: [],
      checked:[],
      task: "",
      select:false
    };
  },
  methods: {
    addTask() {
      this.todos.push(this.task);
      this.task="";
    },
    removeSelectedTask() {
      for(let i of this.checked){
      this.todos=this.todos.filter(todo=>{
        return i !== todo
      });
    }
    this.select=false;
  },
  selectAll(){
    if(this.select){
      this.checked=[];
      for(let i of this.todos){
        this.checked.push(i);
      }
    }else{
      this.checked=[]
    }
  }
  }
};
</script>


<style scoped>
</style>